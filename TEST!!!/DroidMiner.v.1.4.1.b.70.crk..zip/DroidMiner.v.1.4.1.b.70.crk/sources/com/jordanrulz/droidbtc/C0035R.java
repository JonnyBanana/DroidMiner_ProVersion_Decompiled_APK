package com.jordanrulz.droidbtc;

/* renamed from: com.jordanrulz.droidbtc.R */
public final class C0035R {

    /* renamed from: com.jordanrulz.droidbtc.R$attr */
    public static final class attr {
    }

    /* renamed from: com.jordanrulz.droidbtc.R$drawable */
    public static final class drawable {
        public static final int ic_launcher = 2130837504;
        public static final int litecoin = 2130837505;
    }

    /* renamed from: com.jordanrulz.droidbtc.R$id */
    public static final class id {
        public static final int LinearLayout02 = 2131165194;
        public static final int button1 = 2131165195;
        public static final int button2 = 2131165196;
        public static final int editText = 2131165187;
        public static final int editText1 = 2131165186;
        public static final int exit = 2131165200;
        public static final int linar1 = 2131165185;
        public static final int password1 = 2131165189;
        public static final int radioButton = 2131165192;
        public static final int radioButton2 = 2131165193;
        public static final int relativeLayoutOuter = 2131165184;
        public static final int scrollView1 = 2131165198;
        public static final int spinner1 = 2131165191;
        public static final int textView1 = 2131165199;
        public static final int textView4 = 2131165190;
        public static final int textView5 = 2131165197;
        public static final int username1 = 2131165188;
    }

    /* renamed from: com.jordanrulz.droidbtc.R$layout */
    public static final class layout {
        public static final int main = 2130903040;
    }

    /* renamed from: com.jordanrulz.droidbtc.R$menu */
    public static final class menu {
        public static final int menu = 2131099648;
    }

    /* renamed from: com.jordanrulz.droidbtc.R$raw */
    public static final class raw {
        public static final int minerd = 2130968576;
        public static final int minerd_neon = 2130968577;
        public static final int minerd_regular = 2130968578;
    }

    /* renamed from: com.jordanrulz.droidbtc.R$string */
    public static final class string {
        public static final int app_name = 2131034113;
        public static final int hello = 2131034112;
    }
}
