package com.jordanrulz.droidbtc;

public final class BuildConfig {
    public static final boolean DEBUG = false;
}
